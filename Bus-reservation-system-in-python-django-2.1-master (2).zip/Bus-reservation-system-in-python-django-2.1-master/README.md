# Bus-reservation-system-in-python-django-2.1
A simple bus reservation system using django 2.1 in Python

This is a pretty simple implementation of a bus reservation system in Pyhton Django 2.1.
In this project, the users can:
1. Find bus
2. Book bus
3. Cancel bus

